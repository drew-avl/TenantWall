<?php

/**
 * TenantWall — Install / Uninstall / Migrate.
 *
 * CHANGES v0.2 → v0.3
 * ─────────────────────
 * • uninstall() now drops all plugin tables — v0.2 returned true without
 *   touching the DB, leaving orphaned tables on every removal.
 * • install() records the schema version in the config singleton so future
 *   migrations can detect and upgrade existing installations.
 * • Migration helpers apply ALTER TABLE changes only when absent, making
 *   install() safe to re-run as an upgrade.
 * • Added missing index on plugin_tenantwall_tenants_id in tenantentities.
 * • Added schema_version and log_blocked_attempts columns.
 * • Dropped shared_services_root_id (unused in v0.2, replaced by per-tenant
 *   allow_shared_services flag).
 */

declare(strict_types=1);

namespace GlpiPlugin\Tenantwall;

class Install
{
    public static function install(): bool
    {
        global $DB;

        self::createTables($DB);
        self::runMigrations($DB);
        self::ensureConfigSingleton($DB);

        return true;
    }

    public static function uninstall(): bool
    {
        global $DB;

        // Drop in reverse dependency order.
        foreach ([
            'glpi_plugin_tenantwall_tenantentities',
            'glpi_plugin_tenantwall_tenants',
            'glpi_plugin_tenantwall_profiles',
            'glpi_plugin_tenantwall_configs',
        ] as $table) {
            $DB->doQuery("DROP TABLE IF EXISTS `{$table}`");
        }

        return true;
    }

    // ── Private ──────────────────────────────────────────────────────────────

    private static function createTables(object $DB): void
    {
        $cs = 'ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci';

        $DB->doQuery("CREATE TABLE IF NOT EXISTS `glpi_plugin_tenantwall_tenants` (
            `id`                    INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `name`                  VARCHAR(255) NOT NULL,
            `entities_id_root`      INT UNSIGNED NOT NULL DEFAULT 0,
            `include_children`      TINYINT(1)   NOT NULL DEFAULT 1,
            `is_active`             TINYINT(1)   NOT NULL DEFAULT 1,
            `allow_shared_services` TINYINT(1)   NOT NULL DEFAULT 0,
            `notes`                 TEXT NULL,
            `date_creation`         TIMESTAMP NULL DEFAULT NULL,
            `date_mod`              TIMESTAMP NULL DEFAULT NULL,
            PRIMARY KEY (`id`),
            KEY `entities_id_root` (`entities_id_root`),
            KEY `is_active` (`is_active`)
        ) {$cs}");

        $DB->doQuery("CREATE TABLE IF NOT EXISTS `glpi_plugin_tenantwall_tenantentities` (
            `id`                           INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `plugin_tenantwall_tenants_id` INT UNSIGNED NOT NULL,
            `entities_id`                  INT UNSIGNED NOT NULL,
            PRIMARY KEY (`id`),
            UNIQUE KEY `tenant_entity_unique` (`plugin_tenantwall_tenants_id`, `entities_id`),
            KEY `plugin_tenantwall_tenants_id` (`plugin_tenantwall_tenants_id`),
            KEY `entities_id` (`entities_id`)
        ) {$cs}");

        $DB->doQuery("CREATE TABLE IF NOT EXISTS `glpi_plugin_tenantwall_profiles` (
            `id`                       INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `profiles_id`              INT UNSIGNED NOT NULL,
            `bypass_tenantwall`        TINYINT(1)   NOT NULL DEFAULT 0,
            `allow_cross_tenant_read`  TINYINT(1)   NOT NULL DEFAULT 0,
            `allow_cross_tenant_write` TINYINT(1)   NOT NULL DEFAULT 0,
            `restrict_entity_switch`   TINYINT(1)   NOT NULL DEFAULT 1,
            PRIMARY KEY (`id`),
            UNIQUE KEY `profiles_id` (`profiles_id`)
        ) {$cs}");

        $DB->doQuery("CREATE TABLE IF NOT EXISTS `glpi_plugin_tenantwall_configs` (
            `id`                        INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `singleton_key`             VARCHAR(64)  NOT NULL DEFAULT 'default',
            `schema_version`            VARCHAR(20)  NOT NULL DEFAULT '0.5.1',
            `shared_services_entity_id` INT UNSIGNED NULL DEFAULT NULL,
            `enforce_on_search`         TINYINT(1)   NOT NULL DEFAULT 1,
            `enforce_on_write`          TINYINT(1)   NOT NULL DEFAULT 1,
            `enforce_entity_switch`     TINYINT(1)   NOT NULL DEFAULT 1,
            `banner_enabled`            TINYINT(1)   NOT NULL DEFAULT 1,
            `log_blocked_attempts`      TINYINT(1)   NOT NULL DEFAULT 1,
            `date_creation`             TIMESTAMP NULL DEFAULT NULL,
            `date_mod`                  TIMESTAMP NULL DEFAULT NULL,
            PRIMARY KEY (`id`),
            UNIQUE KEY `singleton_key` (`singleton_key`)
        ) {$cs}");
    }

    private static function runMigrations(object $DB): void
    {
        self::addColIfMissing($DB,
            'glpi_plugin_tenantwall_tenants', 'include_children',
            "ALTER TABLE `glpi_plugin_tenantwall_tenants`
             ADD `include_children` TINYINT(1) NOT NULL DEFAULT 1 AFTER `entities_id_root`"
        );

        self::addColIfMissing($DB,
            'glpi_plugin_tenantwall_tenants', 'allow_shared_services',
            "ALTER TABLE `glpi_plugin_tenantwall_tenants`
             ADD `allow_shared_services` TINYINT(1) NOT NULL DEFAULT 0 AFTER `is_active`"
        );

        self::addColIfMissing($DB,
            'glpi_plugin_tenantwall_configs', 'schema_version',
            "ALTER TABLE `glpi_plugin_tenantwall_configs`
             ADD `schema_version` VARCHAR(20) NOT NULL DEFAULT '0.5.1' AFTER `singleton_key`"
        );

        self::addColIfMissing($DB,
            'glpi_plugin_tenantwall_configs', 'shared_services_entity_id',
            "ALTER TABLE `glpi_plugin_tenantwall_configs`
             ADD `shared_services_entity_id` INT UNSIGNED NULL DEFAULT NULL AFTER `schema_version`"
        );

        self::addColIfMissing($DB,
            'glpi_plugin_tenantwall_configs', 'log_blocked_attempts',
            "ALTER TABLE `glpi_plugin_tenantwall_configs`
             ADD `log_blocked_attempts` TINYINT(1) NOT NULL DEFAULT 1"
        );

        // Remove the stale shared_services_root_id column from v0.2 if present.
        self::dropColIfPresent($DB,
            'glpi_plugin_tenantwall_configs', 'shared_services_root_id',
            "ALTER TABLE `glpi_plugin_tenantwall_configs` DROP COLUMN `shared_services_root_id`"
        );
    }

    private static function ensureConfigSingleton(object $DB): void
    {
        $existing = $DB->request([
            'FROM'  => 'glpi_plugin_tenantwall_configs',
            'WHERE' => ['singleton_key' => 'default'],
        ])->current();

        $now = $_SESSION['glpi_currenttime'] ?? date('Y-m-d H:i:s');

        if (!$existing) {
            $DB->insert('glpi_plugin_tenantwall_configs', [
                'singleton_key'  => 'default',
                'schema_version' => PLUGIN_TENANTWALL_SCHEMA_VERSION,
                'date_creation'  => $now,
                'date_mod'       => $now,
            ]);
        } else {
            $DB->update('glpi_plugin_tenantwall_configs', [
                'schema_version' => PLUGIN_TENANTWALL_SCHEMA_VERSION,
                'date_mod'       => $now,
            ], ['singleton_key' => 'default']);
        }
    }

    private static function addColIfMissing(object $DB, string $table, string $col, string $sql): void
    {
        if ($DB->tableExists($table) && !isset($DB->listFields($table)[$col])) {
            $DB->doQuery($sql);
        }
    }

    private static function dropColIfPresent(object $DB, string $table, string $col, string $sql): void
    {
        if ($DB->tableExists($table) && isset($DB->listFields($table)[$col])) {
            $DB->doQuery($sql);
        }
    }
}
