<?php

/**
 * Global config POST handler.
 *
 * CHANGES v0.2 → v0.3
 * • FIX: v0.2 used a raw global $DB block here — all persistence now goes
 *   through Config::save() so field validation and date_mod live in one place.
 * • Added Html::checkFormToken() for CSRF defence-in-depth.
 */

declare(strict_types=1);

include('../../../inc/includes.php');

use GlpiPlugin\Tenantwall\Config;

Session::checkRight('config', UPDATE);
Html::checkFormToken();

Config::save($_POST);
Session::addMessageAfterRedirect(__('TenantWall configuration updated.', 'tenantwall'));

Html::back();
