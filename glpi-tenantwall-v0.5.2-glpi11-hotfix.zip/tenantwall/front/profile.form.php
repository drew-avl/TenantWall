<?php

/**
 * Per-profile policy POST handler.
 *
 * CHANGES v0.2 → v0.3
 * • Added Html::checkFormToken() for CSRF defence-in-depth.
 * • Upsert logic lives here (not in getForProfile) — getForProfile() now
 *   returns defaults without auto-inserting on read.
 */

declare(strict_types=1);

include('../../../inc/includes.php');

Session::checkRight('profile', UPDATE);
Html::checkFormToken();

if (!empty($_POST['profiles_id'])) {
    global $DB;

    $profiles_id = (int)$_POST['profiles_id'];

    $existing = $DB->request([
        'FROM'  => 'glpi_plugin_tenantwall_profiles',
        'WHERE' => ['profiles_id' => $profiles_id],
    ])->current();

    $payload = [
        'profiles_id'              => $profiles_id,
        'bypass_tenantwall'        => (int)($_POST['bypass_tenantwall']        ?? 0),
        'allow_cross_tenant_read'  => (int)($_POST['allow_cross_tenant_read']  ?? 0),
        'allow_cross_tenant_write' => (int)($_POST['allow_cross_tenant_write'] ?? 0),
        'restrict_entity_switch'   => (int)($_POST['restrict_entity_switch']   ?? 1),
    ];

    if ($existing) {
        $DB->update('glpi_plugin_tenantwall_profiles', $payload, ['profiles_id' => $profiles_id]);
    } else {
        $DB->insert('glpi_plugin_tenantwall_profiles', $payload);
    }

    Session::addMessageAfterRedirect(__('TenantWall profile policy updated.', 'tenantwall'));
}

Html::back();
