<?php

declare(strict_types=1);

include('../../../inc/includes.php');

use GlpiPlugin\Tenantwall\Tenant;

Session::checkRight('config', READ);
Html::header(__('TenantWall', 'tenantwall'), '', 'config', 'plugins');

$id     = (int)($_GET['id'] ?? 0);
$tenant = $id > 0 ? Tenant::getById($id) : null;
Tenant::renderAdminPage($tenant);

Html::footer();
