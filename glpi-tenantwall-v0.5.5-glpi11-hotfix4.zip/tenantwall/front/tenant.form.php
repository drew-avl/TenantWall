<?php

/**
 * Tenant create / update / delete handler.
 *
 * CHANGES v0.2 → v0.3
 * • After delete, redirect to list page instead of Html::back() so the user
 *   does not land on a URL referencing the now-deleted tenant ID.
 */

declare(strict_types=1);

include('../../../inc/includes.php');

use GlpiPlugin\Tenantwall\Tenant;

Session::checkRight('config', UPDATE);

try {
    if (isset($_POST['purge']) && (int)$_POST['purge'] === 1) {
        Tenant::delete((int)($_POST['id'] ?? 0));
        Session::addMessageAfterRedirect(__('TenantWall tenant deleted.', 'tenantwall'));
        Html::redirect(Plugin::getWebDir('tenantwall') . '/front/tenant.php');
    } else {
        $id = Tenant::save($_POST);
        Session::addMessageAfterRedirect(__('TenantWall tenant saved.', 'tenantwall'));
        Html::redirect(Plugin::getWebDir('tenantwall') . '/front/tenant.php?id=' . $id);
    }
} catch (Throwable $e) {
    Session::addMessageAfterRedirect(htmlspecialchars($e->getMessage(), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'), false, ERROR);
    Html::back();
}
