<?php

declare(strict_types=1);

namespace GlpiPlugin\Tenantwall;

class Policy
{
    public static function getProfilePolicy(?int $profiles_id = null): array
    {
        global $DB;

        $profiles_id ??= (int)($_SESSION['glpiactiveprofile']['id'] ?? 0);
        if ($profiles_id <= 0) {
            return [];
        }

        return $DB->request([
            'FROM'  => 'glpi_plugin_tenantwall_profiles',
            'WHERE' => ['profiles_id' => $profiles_id],
        ])->current() ?: [];
    }

    public static function getTenantForEntity(int $entities_id): ?array
    {
        global $DB;

        if ($entities_id <= 0) {
            return null;
        }

        $rootMatch = $DB->request([
            'FROM'  => 'glpi_plugin_tenantwall_tenants',
            'WHERE' => [
                'entities_id_root' => $entities_id,
                'is_active'        => 1,
            ],
            'LIMIT' => 1,
        ])->current() ?: null;

        if ($rootMatch) {
            return $rootMatch;
        }

        $explicitMatch = $DB->request([
            'SELECT' => [
                'glpi_plugin_tenantwall_tenants.id',
                'glpi_plugin_tenantwall_tenants.name',
                'glpi_plugin_tenantwall_tenants.entities_id_root',
                'glpi_plugin_tenantwall_tenants.include_children',
                'glpi_plugin_tenantwall_tenants.allow_shared_services',
                'glpi_plugin_tenantwall_tenants.is_active',
                'glpi_plugin_tenantwall_tenants.notes',
            ],
            'FROM'       => 'glpi_plugin_tenantwall_tenantentities',
            'INNER JOIN' => [
                'glpi_plugin_tenantwall_tenants' => [
                    'ON' => [
                        'glpi_plugin_tenantwall_tenantentities' => 'plugin_tenantwall_tenants_id',
                        'glpi_plugin_tenantwall_tenants'        => 'id',
                    ],
                ],
            ],
            'WHERE' => [
                'glpi_plugin_tenantwall_tenantentities.entities_id' => $entities_id,
                'glpi_plugin_tenantwall_tenants.is_active'          => 1,
            ],
            'LIMIT' => 1,
        ])->current() ?: null;

        if ($explicitMatch) {
            return $explicitMatch;
        }

        foreach (Tenant::getAllActive() as $tenant) {
            if (in_array($entities_id, Tenant::getEffectiveEntityIds($tenant), true)) {
                return $tenant;
            }
        }

        return null;
    }

    public static function getActiveTenant(): ?array
    {
        if (self::isAllEntitiesMode()) {
            return null;
        }

        return self::getTenantForEntity((int)($_SESSION['glpiactive_entity'] ?? 0));
    }

    public static function getAccessibleEntityIdsForSession(): array
    {
        if (!isset($_SESSION['plugin_tenantwall']['allowed_entities'])) {
            return [];
        }

        return array_values(array_unique(array_map(
            'intval',
            (array)$_SESSION['plugin_tenantwall']['allowed_entities']
        )));
    }

    public static function isAllEntitiesMode(): bool
    {
        return !empty($_SESSION['glpiactive_entity_recursive'])
            && ((int)($_SESSION['glpiactive_entity'] ?? 0)) === 0;
    }

    public static function canBypass(): bool
    {
        return (bool)(self::getProfilePolicy()['bypass_tenantwall'] ?? false);
    }

    public static function canCrossRead(): bool
    {
        $profile = self::getProfilePolicy();
        return self::canBypass() || (bool)($profile['allow_cross_tenant_read'] ?? false);
    }

    public static function canCrossWrite(): bool
    {
        $profile = self::getProfilePolicy();
        return self::canBypass() || (bool)($profile['allow_cross_tenant_write'] ?? false);
    }

    public static function shouldRestrictEntitySwitch(): bool
    {
        if (self::canBypass()) {
            return false;
        }

        $config  = Config::getSingleton();
        $profile = self::getProfilePolicy();

        if (!(int)($config['enforce_entity_switch'] ?? 1)) {
            return false;
        }

        return (bool)($profile['restrict_entity_switch'] ?? true);
    }
}
