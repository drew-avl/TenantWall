<?php

declare(strict_types=1);

namespace GlpiPlugin\Tenantwall;

use CommonDBTM;
use Html;
use Session;
use Toolbox;

class Guard
{
    public static function refreshSessionContext(): void
    {
        if (!Session::getLoginUserID()) {
            return;
        }

        $previous      = $_SESSION['plugin_tenantwall'] ?? [];
        $allEntities   = Policy::isAllEntitiesMode();
        $tenant        = Policy::getActiveTenant();
        $activeEntity  = (int)($_SESSION['glpiactive_entity'] ?? 0);
        $allowed       = self::resolveAllowedEntities($tenant);
        $fallback      = (int)($previous['fallback_entity'] ?? 0);

        if (!$allEntities && $activeEntity > 0) {
            $fallback = $activeEntity;
        }

        // If the user entered all-entities mode, preserve the last scoped context
        // so we can immediately snap them back into a valid entity when possible.
        if (
            $allEntities
            && !Policy::canCrossRead()
            && $tenant === null
            && $allowed === []
            && !empty($previous['allowed_entities'])
        ) {
            $tenant   = is_array($previous['active_tenant'] ?? null) ? $previous['active_tenant'] : null;
            $allowed  = array_values(array_unique(array_map('intval', $previous['allowed_entities'])));
            $fallback = $fallback > 0 ? $fallback : (int)($previous['active_entity'] ?? 0);
        }

        $_SESSION['plugin_tenantwall'] = [
            'active_entity'     => $activeEntity,
            'active_tenant'     => $tenant,
            'allowed_entities'  => $allowed,
            'all_entities_mode' => $allEntities,
            'fallback_entity'   => $fallback,
        ];

        self::enforceEntitySwitch();
    }

    public static function resolveAllowedEntities(?array $tenant): array
    {
        if (Policy::canCrossRead()) {
            return [];
        }

        if ($tenant !== null) {
            return Tenant::getEffectiveEntityIds($tenant, true);
        }

        if (!Policy::isAllEntitiesMode()) {
            $active = (int)($_SESSION['glpiactive_entity'] ?? 0);
            return $active > 0 ? [$active] : [];
        }

        return [];
    }

    public static function enforceEntitySwitch(): void
    {
        if (!Policy::shouldRestrictEntitySwitch()) {
            return;
        }

        $allowed = Policy::getAccessibleEntityIdsForSession();
        if ($allowed === []) {
            return;
        }

        $active      = (int)($_SESSION['glpiactive_entity'] ?? 0);
        $allEntities = (bool)($_SESSION['plugin_tenantwall']['all_entities_mode'] ?? false);
        $fallback    = (int)($_SESSION['plugin_tenantwall']['fallback_entity'] ?? 0);

        if ($fallback <= 0 || !in_array($fallback, $allowed, true)) {
            $fallback = $allowed[0];
        }

        if ($allEntities || !in_array($active, $allowed, true)) {
            self::log(sprintf(
                'Blocked entity context — active=%d, all_entities=%s, allowed=%s, fallback=%d',
                $active,
                $allEntities ? 'yes' : 'no',
                implode(',', $allowed),
                $fallback
            ));

            Session::addMessageAfterRedirect(
                __('TenantWall restored a tenant-scoped entity context.', 'tenantwall'),
                false,
                WARNING
            );

            Session::changeActiveEntities($fallback, false);
            $_SESSION['plugin_tenantwall']['active_entity'] = $fallback;
            $_SESSION['plugin_tenantwall']['active_tenant'] = Policy::getTenantForEntity($fallback);
            $_SESSION['plugin_tenantwall']['all_entities_mode'] = false;
            $_SESSION['plugin_tenantwall']['fallback_entity'] = $fallback;
        }
    }

    public static function displayContextBanner(): void
    {
        $config = Config::getSingleton();
        if (!(int)($config['banner_enabled'] ?? 1)) {
            return;
        }

        $entity = $_SESSION['glpiactive_entity_name']
            ?? ('#' . (int)($_SESSION['glpiactive_entity'] ?? 0));

        if ($_SESSION['plugin_tenantwall']['all_entities_mode'] ?? false) {
            echo '<div class="alert alert-warning tenantwall-banner">'
                . '<strong>TenantWall</strong> — '
                . htmlspecialchars(sprintf(
                    __('All-entities mode was requested. Current entity context: %s', 'tenantwall'),
                    (string)$entity
                ), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8')
                . '</div>';
            return;
        }

        $tenant = $_SESSION['plugin_tenantwall']['active_tenant']['name'] ?? null;

        if ($tenant) {
            $cls = 'alert-info';
            $msg = sprintf(
                __('Tenant: %s | Entity: %s', 'tenantwall'),
                (string)$tenant,
                (string)$entity
            );
        } else {
            $cls = 'alert-warning';
            $msg = sprintf(
                __('No tenant mapping for entity: %s — access limited to this entity.', 'tenantwall'),
                (string)$entity
            );
        }

        echo '<div class="alert ' . $cls . ' tenantwall-banner">'
            . '<strong>TenantWall</strong> — ' . htmlspecialchars($msg, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8')
            . '</div>';
    }

    public static function preItemAdd(CommonDBTM $item): void
    {
        self::enforceWriteBoundary($item, true, 'add');
    }

    public static function preItemUpdate(CommonDBTM $item): void
    {
        self::enforceWriteBoundary($item, false, 'update');
    }

    public static function preItemDelete(CommonDBTM $item): void
    {
        self::enforceWriteBoundary($item, false, 'delete');
    }

    public static function preItemPurge(CommonDBTM $item): void
    {
        self::enforceWriteBoundary($item, false, 'purge');
    }

    public static function preItemRestore(CommonDBTM $item): void
    {
        self::enforceWriteBoundary($item, false, 'restore');
    }

    private static function enforceWriteBoundary(CommonDBTM $item, bool $isNew, string $operation): void
    {
        $config = Config::getSingleton();
        if (!(int)($config['enforce_on_write'] ?? 1) || Policy::canCrossWrite()) {
            return;
        }

        $allowed = Policy::getAccessibleEntityIdsForSession();
        if ($allowed === []) {
            return;
        }

        $entityId = self::extractEntityId($item, $isNew)
            ?? (int)($_SESSION['glpiactive_entity'] ?? 0);

        if ($entityId > 0 && in_array($entityId, $allowed, true)) {
            return;
        }

        self::log(sprintf(
            'Blocked %s — %s #%d in entity #%d outside tenant boundary (allowed: %s)',
            $operation,
            $item->getType(),
            (int)($item->fields['id'] ?? 0),
            $entityId,
            implode(',', $allowed)
        ));

        Session::addMessageAfterRedirect(
            __('TenantWall blocked a write outside the active tenant boundary.', 'tenantwall'),
            false,
            ERROR
        );

        $item->input = false;
    }

    private static function extractEntityId(CommonDBTM $item, bool $preferInput = false): ?int
    {
        if ($preferInput && isset($item->input['entities_id'])) {
            return (int)$item->input['entities_id'];
        }
        if (isset($item->input['entities_id'])) {
            return (int)$item->input['entities_id'];
        }
        if (isset($item->fields['entities_id'])) {
            return (int)$item->fields['entities_id'];
        }
        return null;
    }

    private static function log(string $message): void
    {
        $config = Config::getSingleton();
        if (!(int)($config['log_blocked_attempts'] ?? 1)) {
            return;
        }

        Toolbox::logInFile(
            'plugin_tenantwall',
            sprintf('[user=%d] %s', (int) Session::getLoginUserID(), $message) . PHP_EOL
        );
    }
}
