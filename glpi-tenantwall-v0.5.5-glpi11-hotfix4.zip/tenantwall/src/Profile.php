<?php

/**
 * TenantWall — per-profile policy tab (appears on GLPI's Profile pages).
 *
 * CHANGES v0.2 → v0.3
 * ─────────────────────
 * • FIX: Was `extends \Profile`. \Profile extends CommonDBTM and its
 *   getTable() returns 'glpi_profiles' — GLPI's core profile table. Any
 *   inherited ORM method would operate on the wrong table. Correct base is
 *   CommonGLPI.
 * • FIX: Added missing `use Plugin` and `use Dropdown`.
 * • FIX: getForProfile() previously called $DB->insert() on every page read,
 *   silently creating rows for every profile that had never been saved.
 *   getForProfile() now returns safe in-memory defaults without touching the
 *   DB. The row is created only on first save (front/profile.form.php).
 * • showForProfile() now respects profile READ vs UPDATE rights and renders
 *   read-only badges when the viewer lacks UPDATE.
 * • instanceof used instead of getType() string comparison.
 */

declare(strict_types=1);

namespace GlpiPlugin\Tenantwall;

use CommonGLPI;
use Dropdown;
use Html;
use Plugin;
use Session;

class Profile extends CommonGLPI
{
    public static function getTypeName($nb = 0): string
    {
        return __('TenantWall policy', 'tenantwall');
    }

    // ── Tab interface ────────────────────────────────────────────────────────

    public function getTabNameForItem(CommonGLPI $item, $withtemplate = 0)
    {
        if ($item instanceof \Profile) {
            return self::createTabEntry(__('TenantWall', 'tenantwall'));
        }
        return '';
    }

    public static function displayTabContentForItem(
        CommonGLPI $item,
        $tabnum = 1,
        $withtemplate = 0
    ): bool {
        if ($item instanceof \Profile) {
            self::showForProfile((int)$item->getID());
        }
        return true;
    }

    // ── Data ─────────────────────────────────────────────────────────────────

    /**
     * Returns the saved policy row, or safe in-memory defaults.
     * Does NOT insert a row — deferred to first save.
     */
    public static function getForProfile(int $profiles_id): array
    {
        global $DB;

        if ($profiles_id <= 0) {
            return self::defaults($profiles_id);
        }

        return $DB->request([
            'FROM'  => 'glpi_plugin_tenantwall_profiles',
            'WHERE' => ['profiles_id' => $profiles_id],
        ])->current() ?: self::defaults($profiles_id);
    }

    private static function defaults(int $profiles_id): array
    {
        return [
            'profiles_id'              => $profiles_id,
            'bypass_tenantwall'        => 0,
            'allow_cross_tenant_read'  => 0,
            'allow_cross_tenant_write' => 0,
            'restrict_entity_switch'   => 1,
        ];
    }

    // ── Render ───────────────────────────────────────────────────────────────

    public static function showForProfile(int $profiles_id): void
    {
        if (!Session::haveRight('profile', READ)) {
            return;
        }

        $canEdit = (bool) Session::haveRight('profile', UPDATE);
        $row     = self::getForProfile($profiles_id);
        $action  = Plugin::getWebDir('tenantwall') . '/front/profile.form.php';

        echo '<form method="post" action="' . $action . '">';
        echo Html::hidden('profiles_id', ['value' => $profiles_id]);
        echo Html::hidden('_glpi_csrf_token', ['value' => Session::getNewCSRFToken()]);

        echo '<div class="card">';
        echo '<div class="card-header"><h3>' . __('TenantWall policy', 'tenantwall') . '</h3></div>';
        echo '<div class="card-body"><table class="tab_cadre_fixe">';

        self::policyRow(__('Bypass all tenant checks (superuser profiles only)', 'tenantwall'), 'bypass_tenantwall',        (int)($row['bypass_tenantwall']        ?? 0), $canEdit);
        self::policyRow(__('Allow cross-tenant read', 'tenantwall'),                             'allow_cross_tenant_read',  (int)($row['allow_cross_tenant_read']  ?? 0), $canEdit);
        self::policyRow(__('Allow cross-tenant write', 'tenantwall'),                            'allow_cross_tenant_write', (int)($row['allow_cross_tenant_write'] ?? 0), $canEdit);
        self::policyRow(__('Enforce entity-switch restriction', 'tenantwall'),                   'restrict_entity_switch',   (int)($row['restrict_entity_switch']   ?? 1), $canEdit);

        echo '</table></div>';
        echo '<div class="card-footer">';
        if ($canEdit) {
            echo Html::submit(_sx('button', 'Save'));
        }
        echo '</div></div>';
        Html::closeForm();
    }

    private static function policyRow(string $label, string $name, int $value, bool $canEdit): void
    {
        echo '<tr><td>' . $label . '</td><td>';
        if ($canEdit) {
            Dropdown::showYesNo($name, $value);
        } else {
            $cls = $value ? 'bg-success' : 'bg-secondary';
            echo '<span class="badge ' . $cls . '">' . ($value ? __('Yes') : __('No')) . '</span>';
        }
        echo '</td></tr>';
    }
}
