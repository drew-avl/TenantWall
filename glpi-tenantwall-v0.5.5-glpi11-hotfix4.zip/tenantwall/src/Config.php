<?php

declare(strict_types=1);

namespace GlpiPlugin\Tenantwall;

use CommonGLPI;
use Dropdown;
use Html;
use Plugin;
use Session;

class Config extends CommonGLPI
{
    public static $rightname = 'config';

    public static function getTypeName($nb = 0): string
    {
        return __('TenantWall', 'tenantwall');
    }

    public static function canView(): bool
    {
        return (bool) Session::haveRight(self::$rightname, READ);
    }

    public static function canUpdate(): bool
    {
        return (bool) Session::haveRight(self::$rightname, UPDATE);
    }

    public function getTabNameForItem(CommonGLPI $item, $withtemplate = 0)
    {
        if ($item instanceof \Config) {
            return self::createTabEntry(self::getTypeName());
        }
        return '';
    }

    public static function displayTabContentForItem(
        CommonGLPI $item,
        $tabnum = 1,
        $withtemplate = 0
    ): bool {
        if ($item instanceof \Config) {
            self::showConfigTab();
        }
        return true;
    }

    public static function getSingleton(): array
    {
        global $DB;

        return $DB->request([
            'FROM'  => 'glpi_plugin_tenantwall_configs',
            'WHERE' => ['singleton_key' => 'default'],
        ])->current() ?: [];
    }

    public static function save(array $input): bool
    {
        global $DB;

        $id = (int)($input['id'] ?? 0);
        $sharedServices = max(0, (int)($input['shared_services_entity_id'] ?? 0));
        $now = $_SESSION['glpi_currenttime'] ?? date('Y-m-d H:i:s');

        $payload = [
            'shared_services_entity_id' => $sharedServices > 0 ? $sharedServices : null,
            'enforce_on_search'         => (int)($input['enforce_on_search'] ?? 1),
            'enforce_on_write'          => (int)($input['enforce_on_write'] ?? 1),
            'enforce_entity_switch'     => (int)($input['enforce_entity_switch'] ?? 1),
            'banner_enabled'            => (int)($input['banner_enabled'] ?? 1),
            'log_blocked_attempts'      => (int)($input['log_blocked_attempts'] ?? 1),
            'date_mod'                  => $now,
        ];

        if ($id > 0) {
            $DB->update('glpi_plugin_tenantwall_configs', $payload, ['id' => $id]);
        } else {
            $existing = self::getSingleton();
            if ($existing) {
                $DB->update('glpi_plugin_tenantwall_configs', $payload, ['id' => (int)$existing['id']]);
            } else {
                $payload['singleton_key'] = 'default';
                $payload['schema_version'] = defined('PLUGIN_TENANTWALL_SCHEMA_VERSION') ? PLUGIN_TENANTWALL_SCHEMA_VERSION : '0.5.4';
                $payload['date_creation'] = $now;
                $DB->insert('glpi_plugin_tenantwall_configs', $payload);
            }
        }

        return true;
    }

    public static function getSharedServicesEntityId(): int
    {
        return (int)(self::getSingleton()['shared_services_entity_id'] ?? 0);
    }

    public static function showConfigTab(): void
    {
        if (!self::canView()) {
            return;
        }

        $config        = self::getSingleton();
        $action        = Plugin::getWebDir('tenantwall') . '/front/config.form.php';
        $entityOptions = Tenant::getEntityOptions(true);
        $sharedId      = (int)($config['shared_services_entity_id'] ?? 0);

        $canEdit       = self::canUpdate();

        echo '<form method="post" action="' . $action . '">';
        echo Html::hidden('id', ['value' => (int)($config['id'] ?? 0)]);
        echo Html::hidden('_glpi_csrf_token', ['value' => Session::getNewCSRFToken()]);

        echo '<div class="card">';
        echo '<div class="card-header"><h3>' . __('TenantWall configuration', 'tenantwall') . '</h3></div>';
        echo '<div class="card-body"><table class="tab_cadre_fixe">';
        echo '<tr><th colspan="2">' . __('Global segmentation policy', 'tenantwall') . '</th></tr>';

        echo '<tr><td>' . __('Shared Services entity', 'tenantwall') . '</td><td>';
        echo self::buildSelect('shared_services_entity_id', $sharedId, $entityOptions, true, !$canEdit);
        echo '<div class="tenantwall-muted mt-1">'
            . __('Optional. Tenants with shared-services overlap enabled will also be allowed into this entity.', 'tenantwall')
            . '</div>';
        echo '</td></tr>';

        self::row(__('Restrict writes to the active tenant', 'tenantwall'), 'enforce_on_write', (int)($config['enforce_on_write'] ?? 1), $canEdit);
        self::row(__('Restrict entity switching outside the tenant boundary', 'tenantwall'), 'enforce_entity_switch', (int)($config['enforce_entity_switch'] ?? 1), $canEdit);
        self::row(__('Show tenant context banner on dashboard', 'tenantwall'), 'banner_enabled', (int)($config['banner_enabled'] ?? 1), $canEdit);
        self::row(__('Log blocked access attempts to plugin log file', 'tenantwall'), 'log_blocked_attempts', (int)($config['log_blocked_attempts'] ?? 1), $canEdit);

        echo '</table></div>';
        echo '<div class="card-footer">';
        if ($canEdit) {
            echo Html::submit(_sx('button', 'Save'));
        }
        echo '</div></div>';
        Html::closeForm();

        if ($canEdit) {
            echo '<div class="mt-3">';
            echo '<a class="btn btn-primary" href="' . Plugin::getWebDir('tenantwall') . '/front/tenant.php">'
                . __('Manage tenants', 'tenantwall') . '</a>';
            echo '</div>';
        }
    }

    private static function row(string $label, string $name, int $value, bool $canEdit): void
    {
        echo '<tr><td>' . $label . '</td><td>';
        if ($canEdit) {
            Dropdown::showYesNo($name, $value);
        } else {
            $cls = $value ? 'bg-success' : 'bg-secondary';
            echo '<span class="badge ' . $cls . '">' . ($value ? __('Yes') : __('No')) . '</span>';
        }
        echo '</td></tr>';
    }

    private static function buildSelect(string $name, int $current, array $options, bool $allowNone = false, bool $disabled = false): string
    {
        $html = '<select class="form-select" name="' . htmlspecialchars($name, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '"' . ($disabled ? ' disabled' : '') . '>';
        if ($allowNone) {
            $html .= '<option value="0">' . __('None') . '</option>';
        }
        foreach ($options as $id => $label) {
            $html .= '<option value="' . (int)$id . '"' . ((int)$id === $current ? ' selected' : '') . '>'
                . htmlspecialchars($label, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '</option>';
        }
        return $html . '</select>';
    }
}
