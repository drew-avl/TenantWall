## GLPI 11 build

This package targets GLPI 11.x and PHP 8.2+.

# TenantWall for GLPI — v0.4.1

TenantWall hardens GLPI's entity model for MSP and holding-company deployments where each customer should behave like a distinct tenant inside a single GLPI instance.

## What was improved in v0.4

- Fixed write-hook registration so pre-item guards are attached under the plugin name and actually fire.
- Added soft-delete guarding with `pre_item_delete` in addition to purge guarding.
- Fixed tenant resolution for:
  - root entities,
  - manually assigned extra entities,
  - child entities reached through `include_children`.
- Added `shared_services_entity_id` to the global config UI and enforced it in allowed-entity resolution when a tenant enables shared-services overlap.
- Added overlap validation so active tenants cannot claim the same entity scope.
- Prevented the GLPI system root entity from being selected as an extra entity.
- Improved all-entities recovery by snapping restricted users back to a tenant-scoped entity when prior scoped context exists.
- Removed packaging garbage from the release archive.

## Recommended entity structure

```text
N45
├── Internal
├── Shared Services
├── Client A
├── Client B
└── Client C
```

Define each customer root as a Tenant. Reserve bypass and cross-tenant rights for a very small number of internal profiles.

## Current enforcement model

TenantWall enforces segmentation through three layers:

1. **Entity context control**
   - restricted profiles are pushed back into an allowed entity if they try to switch outside their tenant boundary.
2. **Write guards**
   - add, update, delete, and purge actions are blocked before DB write when the target entity falls outside the active tenant boundary.
3. **Tenant scope validation**
   - overlapping active tenant scopes are rejected during configuration.

## Shared Services

Configure a global **Shared Services entity** in the TenantWall config tab. Any tenant with **Allow shared-services overlap** enabled gains access to that entity in addition to its own scope.

## Known limitations

- This is still an enforcement layer on top of GLPI entities, not true hard multitenancy.
- Fresh sessions that begin directly in all-entities mode may still need tighter handling depending on your GLPI defaults and profile design.
- Explicit per-item search hardening beyond GLPI's entity scoping is still not implemented in this release.
- v0.4.1 changes the write guard to stop operations by setting `input=false`, adds restore guarding, and hardens config/migration behavior.
- No automated tests or localization bundles yet.

## Install

1. Copy to `glpi/plugins/tenantwall`
2. Run `composer dump-autoload -o` if your GLPI setup expects it
3. Install and enable the plugin in GLPI
4. Configure the Shared Services entity and tenant definitions
