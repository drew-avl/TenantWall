<?php

declare(strict_types=1);

use GlpiPlugin\Tenantwall\Install;

function plugin_tenantwall_install(): bool
{
    return Install::install();
}

function plugin_tenantwall_uninstall(): bool
{
    return Install::uninstall();
}
