<?php

declare(strict_types=1);

use Glpi\Plugin\Hooks;
use GlpiPlugin\Tenantwall\Config;
use GlpiPlugin\Tenantwall\Guard;
use GlpiPlugin\Tenantwall\Profile;
use GlpiPlugin\Tenantwall\Tenant;

const PLUGIN_TENANTWALL_VERSION        = '0.5.4';
const PLUGIN_TENANTWALL_SCHEMA_VERSION = '0.5.4';
const PLUGIN_TENANTWALL_MIN_GLPI       = '11.0.0';
const PLUGIN_TENANTWALL_MAX_GLPI       = '12.0.0';

function plugin_version_tenantwall(): array
{
    return [
        'name'         => 'TenantWall',
        'version'      => PLUGIN_TENANTWALL_VERSION,
        'author'       => 'N45',
        'license'      => 'GPLv3+',
        'homepage'     => 'https://n45.org',
        'requirements' => [
            'glpi' => [
                'min' => PLUGIN_TENANTWALL_MIN_GLPI,
                'max' => PLUGIN_TENANTWALL_MAX_GLPI,
            ],
            'php' => ['min' => '8.2'],
        ],
    ];
}

function plugin_init_tenantwall(): void
{
    global $PLUGIN_HOOKS;

    $PLUGIN_HOOKS[Hooks::CSRF_COMPLIANT]['tenantwall'] = true;

    $PLUGIN_HOOKS[Hooks::INIT_SESSION]['tenantwall']   = [Guard::class, 'refreshSessionContext'];
    $PLUGIN_HOOKS[Hooks::CHANGE_ENTITY]['tenantwall']  = [Guard::class, 'refreshSessionContext'];
    $PLUGIN_HOOKS[Hooks::CHANGE_PROFILE]['tenantwall'] = [Guard::class, 'refreshSessionContext'];
    $PLUGIN_HOOKS[Hooks::DISPLAY_CENTRAL]['tenantwall'] = [Guard::class, 'displayContextBanner'];
    $PLUGIN_HOOKS[Hooks::ADD_CSS]['tenantwall'] = 'public/css/tenantwall.css';

    $guarded_types = [
        'Entity',
        'Ticket', 'Problem', 'Change',
        'Computer', 'Monitor', 'NetworkEquipment',
        'Phone', 'Printer', 'Peripheral',
        'Software', 'Document', 'Supplier',
        'Contract', 'Project', 'Group',
        'User', 'Location', 'Contact',
        'Budget', 'Certificate', 'Appliance',
        'Database', 'Enclosure', 'Line',
        'PDU', 'PassiveDCEquipment',
        'Rack', 'Cable',
    ];

    foreach ($guarded_types as $type) {
        $PLUGIN_HOOKS[Hooks::PRE_ITEM_ADD]['tenantwall'][$type]    = [Guard::class, 'preItemAdd'];
        $PLUGIN_HOOKS[Hooks::PRE_ITEM_UPDATE]['tenantwall'][$type] = [Guard::class, 'preItemUpdate'];
        $PLUGIN_HOOKS[Hooks::PRE_ITEM_DELETE]['tenantwall'][$type] = [Guard::class, 'preItemDelete'];
        $PLUGIN_HOOKS[Hooks::PRE_ITEM_PURGE]['tenantwall'][$type]  = [Guard::class, 'preItemPurge'];
        $PLUGIN_HOOKS[Hooks::PRE_ITEM_RESTORE]['tenantwall'][$type] = [Guard::class, 'preItemRestore'];
    }

    if (Session::getLoginUserID()) {
        Plugin::registerClass(Profile::class, ['addtabon' => ['Profile']]);
        Plugin::registerClass(Config::class, ['addtabon' => ['Config']]);
        if (Session::haveRight('config', UPDATE)) {
            $PLUGIN_HOOKS[Hooks::CONFIG_PAGE]['tenantwall'] = 'front/tenant.php';
        }
    }
}

function plugin_tenantwall_check_prerequisites(): bool
{
    return version_compare(GLPI_VERSION, PLUGIN_TENANTWALL_MIN_GLPI, '>=')
        && version_compare(GLPI_VERSION, PLUGIN_TENANTWALL_MAX_GLPI, '<');
}

function plugin_tenantwall_check_config(bool $verbose = false): bool
{
    return true;
}

function plugin_tenantwall_getDatabaseRelations(): array
{
    return [];
}
