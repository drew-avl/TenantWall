<?php

declare(strict_types=1);

namespace GlpiPlugin\Tenantwall;

use Dropdown;
use Html;
use Plugin;
use Session;

class Tenant
{
    public static function getAll(): array
    {
        global $DB;

        $rows = [];
        foreach ($DB->request([
            'FROM'  => 'glpi_plugin_tenantwall_tenants',
            'ORDER' => 'name ASC',
        ]) as $row) {
            $rows[] = $row;
        }

        return $rows;
    }

    public static function getAllActive(): array
    {
        return array_values(array_filter(
            self::getAll(),
            static fn(array $tenant): bool => (int)($tenant['is_active'] ?? 0) === 1
        ));
    }

    public static function getById(int $id): ?array
    {
        global $DB;

        if ($id <= 0) {
            return null;
        }

        return $DB->request([
            'FROM'  => 'glpi_plugin_tenantwall_tenants',
            'WHERE' => ['id' => $id],
        ])->current() ?: null;
    }

    public static function getEntityAssignments(int $tenantId): array
    {
        global $DB;

        if ($tenantId <= 0) {
            return [];
        }

        $ids = [];
        foreach ($DB->request([
            'SELECT' => ['entities_id'],
            'FROM'   => 'glpi_plugin_tenantwall_tenantentities',
            'WHERE'  => ['plugin_tenantwall_tenants_id' => $tenantId],
            'ORDER'  => 'entities_id ASC',
        ]) as $row) {
            $ids[] = (int)$row['entities_id'];
        }

        return $ids;
    }

    public static function getEffectiveEntityIds(array $tenant, bool $includeSharedServices = false): array
    {
        $scope = self::buildEffectiveEntityIds(
            (int)($tenant['entities_id_root'] ?? 0),
            self::getEntityAssignments((int)($tenant['id'] ?? 0)),
            (int)($tenant['include_children'] ?? 1) === 1
        );

        if ($includeSharedServices && (int)($tenant['allow_shared_services'] ?? 0) === 1) {
            $sharedServicesId = Config::getSharedServicesEntityId();
            if ($sharedServicesId > 0) {
                $scope[] = $sharedServicesId;
            }
        }

        return array_values(array_unique(array_map('intval', $scope)));
    }

    public static function save(array $input): int
    {
        global $DB;

        $id       = (int)($input['id'] ?? 0);
        $now      = $_SESSION['glpi_currenttime'] ?? date('Y-m-d H:i:s');
        $extraIds = self::normalizeExtraEntityIds($input, (int)($input['entities_id_root'] ?? 0));

        $payload = [
            'name'                  => trim((string)($input['name'] ?? '')),
            'entities_id_root'      => max(0, (int)($input['entities_id_root'] ?? 0)),
            'include_children'      => (int)($input['include_children'] ?? 1),
            'is_active'             => (int)($input['is_active'] ?? 1),
            'allow_shared_services' => (int)($input['allow_shared_services'] ?? 0),
            'notes'                 => trim((string)($input['notes'] ?? '')),
            'date_mod'              => $now,
        ];

        self::validatePayload($id, $payload, $extraIds);

        if ($id > 0) {
            $DB->update('glpi_plugin_tenantwall_tenants', $payload, ['id' => $id]);
        } else {
            $payload['date_creation'] = $now;
            $DB->insert('glpi_plugin_tenantwall_tenants', $payload);
            $id = (int)$DB->insertId();
        }

        self::syncEntityAssignments($id, $extraIds);

        return $id;
    }

    public static function delete(int $id): void
    {
        global $DB;

        if ($id <= 0) {
            return;
        }

        $DB->delete('glpi_plugin_tenantwall_tenantentities', ['plugin_tenantwall_tenants_id' => $id]);
        $DB->delete('glpi_plugin_tenantwall_tenants', ['id' => $id]);
    }

    public static function getEntityOptions(bool $excludeGlpiRoot = false): array
    {
        global $DB;

        $where   = $excludeGlpiRoot ? ['id' => ['>', 0]] : [];
        $options = [];

        foreach ($DB->request([
            'SELECT' => ['id', 'name', 'completename'],
            'FROM'   => 'glpi_entities',
            'WHERE'  => $where,
            'ORDER'  => 'completename ASC',
        ]) as $row) {
            $options[(int)$row['id']] = $row['completename'] ?: $row['name'] ?: ('#' . $row['id']);
        }

        return $options;
    }

    public static function renderAdminPage(?array $currentTenant = null): void
    {
        if (!Session::haveRight('config', READ)) {
            return;
        }

        $canEdit      = Session::haveRight('config', UPDATE);
        $rootOptions    = self::getEntityOptions(true);
        $extraOptions   = self::getEntityOptions(true);
        $tenants        = self::getAll();
        $selected       = $currentTenant ?: [
            'id' => 0,
            'name' => '',
            'entities_id_root' => 0,
            'include_children' => 1,
            'is_active' => 1,
            'allow_shared_services' => 0,
            'notes' => '',
        ];
        $assignedExtras = (int)$selected['id'] > 0
            ? self::getEntityAssignments((int)$selected['id'])
            : [];

        $formAction = Plugin::getWebDir('tenantwall') . '/front/tenant.form.php';
        $listUrl    = Plugin::getWebDir('tenantwall') . '/front/tenant.php';

        echo '<div class="tenantwall-grid">';

        echo '<section class="tenantwall-card">';
        echo '<h2>'
            . ((int)$selected['id'] > 0 ? __('Edit tenant', 'tenantwall') : __('Create tenant', 'tenantwall'))
            . '</h2>';
        echo '<form method="post" action="' . $formAction . '">';
        echo Html::hidden('id', ['value' => (int)$selected['id']]);
        echo Html::hidden('_glpi_csrf_token', ['value' => Session::getNewCSRFToken()]);
        echo '<table class="tab_cadre_fixe">';

        echo '<tr><td>' . __('Tenant name', 'tenantwall') . '</td><td>';
        echo '<input type="text" class="form-control" name="name"' . ($canEdit ? ' required' : ' readonly') . ' value="'
            . htmlspecialchars((string)$selected['name'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '">';
        echo '</td></tr>';

        echo '<tr><td>' . __('Root entity', 'tenantwall') . '</td><td>';
        echo self::buildSelect('entities_id_root', (int)$selected['entities_id_root'], $rootOptions, false, [], !$canEdit);
        echo '</td></tr>';

        echo '<tr><td>' . __('Extra entity assignments', 'tenantwall') . '</td><td>';
        echo self::buildSelect('entities_ids[]', 0, $extraOptions, true, $assignedExtras, !$canEdit);
        echo '<div class="tenantwall-muted mt-1">'
            . __('Optional non-child entities to include in this tenant scope. Overlaps with other tenants are rejected.', 'tenantwall')
            . '</div>';
        echo '</td></tr>';

        echo '<tr><td>' . __('Include child entities', 'tenantwall') . '</td><td>';
        self::yesNoField('include_children', (int)$selected['include_children'], $canEdit);
        echo '</td></tr>';

        echo '<tr><td>' . __('Active', 'tenantwall') . '</td><td>';
        self::yesNoField('is_active', (int)$selected['is_active'], $canEdit);
        echo '</td></tr>';

        echo '<tr><td>' . __('Allow shared-services overlap', 'tenantwall') . '</td><td>';
        self::yesNoField('allow_shared_services', (int)$selected['allow_shared_services'], $canEdit);
        echo '<div class="tenantwall-muted mt-1">'
            . __('Allow this tenant to also access the Shared Services entity configured in TenantWall settings.', 'tenantwall')
            . '</div>';
        echo '</td></tr>';

        echo '<tr><td>' . __('Notes', 'tenantwall') . '</td><td>';
        echo '<textarea class="form-control" name="notes" rows="4"' . ($canEdit ? '' : ' readonly') . '>'
            . htmlspecialchars((string)$selected['notes'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '</textarea>';
        echo '</td></tr>';

        echo '</table>';
        echo '<div class="mt-3 d-flex gap-2">';
        if ($canEdit) {
            echo Html::submit(_sx('button', 'Save'));
        }
        if ((int)$selected['id'] > 0 && $canEdit) {
            echo '<a class="btn btn-secondary" href="' . $listUrl . '">' . __('New tenant', 'tenantwall') . '</a>';
        }
        echo '</div></form></section>';

        echo '<section class="tenantwall-card tenantwall-list">';
        echo '<h2>' . __('Configured tenants', 'tenantwall') . '</h2>';
        echo '<table class="tab_cadre_fixehov">';
        echo '<thead><tr>';
        echo '<th>' . __('Name', 'tenantwall') . '</th>';
        echo '<th>' . __('Root entity', 'tenantwall') . '</th>';
        echo '<th>' . __('Mode', 'tenantwall') . '</th>';
        echo '<th>' . __('Status', 'tenantwall') . '</th>';
        echo '<th></th>';
        echo '</tr></thead><tbody>';

        foreach ($tenants as $tenant) {
            $rootLabel = $rootOptions[(int)$tenant['entities_id_root']] ?? ('#' . (int)$tenant['entities_id_root']);

            echo '<tr>';
            echo '<td>' . htmlspecialchars((string)$tenant['name'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '</td>';
            echo '<td>' . htmlspecialchars($rootLabel, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '</td>';
            echo '<td>'
                . ((int)$tenant['include_children'] ? __('Root + children', 'tenantwall') : __('Manual scope', 'tenantwall'))
                . '</td>';
            echo '<td>';
            echo (int)$tenant['is_active']
                ? '<span class="badge bg-success">' . __('Active', 'tenantwall') . '</span>'
                : '<span class="badge bg-secondary">' . __('Disabled', 'tenantwall') . '</span>';
            echo '</td>';
            echo '<td class="text-end">';
            echo '<a class="btn btn-sm btn-primary" href="' . $listUrl . '?id=' . (int)$tenant['id'] . '">'
                . ($canEdit ? __('Edit', 'tenantwall') : __('View', 'tenantwall')) . '</a> ';
            if ($canEdit) {
                echo '<form style="display:inline" method="post" action="' . $formAction . '" '
                    . 'onsubmit="return confirm(\'' . addslashes(__('Delete this tenant?', 'tenantwall')) . '\')">';
                echo Html::hidden('id', ['value' => (int)$tenant['id']]);
                echo Html::hidden('purge', ['value' => 1]);
                echo Html::hidden('_glpi_csrf_token', ['value' => Session::getNewCSRFToken()]);
                echo '<button class="btn btn-sm btn-outline-danger" type="submit">'
                    . __('Delete', 'tenantwall') . '</button>';
                echo '</form>';
            }
            echo '</td></tr>';
        }

        if ($tenants === []) {
            echo '<tr><td colspan="5">' . __('No tenants configured yet.', 'tenantwall') . '</td></tr>';
        }

        echo '</tbody></table></section>';
        echo '</div>';
    }

    public static function getEntityAncestry(int $entityId): array
    {
        global $DB;

        $ancestry = [];
        $seen     = [];
        $current  = $entityId;

        while ($current > 0 && !isset($seen[$current])) {
            $seen[$current] = true;
            $ancestry[] = $current;

            $row = $DB->request([
                'SELECT' => ['entities_id'],
                'FROM'   => 'glpi_entities',
                'WHERE'  => ['id' => $current],
                'LIMIT'  => 1,
            ])->current();

            $current = (int)($row['entities_id'] ?? 0);
        }

        return $ancestry;
    }

    private static function syncEntityAssignments(int $tenantId, array $entityIds): void
    {
        global $DB;

        $DB->delete('glpi_plugin_tenantwall_tenantentities', ['plugin_tenantwall_tenants_id' => $tenantId]);

        foreach (array_unique(array_map('intval', $entityIds)) as $entityId) {
            if ($entityId > 0) {
                $DB->insert('glpi_plugin_tenantwall_tenantentities', [
                    'plugin_tenantwall_tenants_id' => $tenantId,
                    'entities_id'                  => $entityId,
                ]);
            }
        }
    }

    private static function normalizeExtraEntityIds(array $input, int $rootId): array
    {
        $extra = $input['entities_ids'] ?? [];
        if (!is_array($extra)) {
            $extra = [$extra];
        }

        $ids = [];
        foreach ($extra as $raw) {
            $id = (int)$raw;
            if ($id > 0 && $id !== $rootId) {
                $ids[] = $id;
            }
        }

        return array_values(array_unique($ids));
    }

    private static function validatePayload(int $currentId, array $payload, array $extraIds): void
    {
        if ($payload['name'] === '') {
            throw new \RuntimeException(__('Tenant name is required.', 'tenantwall'));
        }

        if ((int)$payload['entities_id_root'] <= 0) {
            throw new \RuntimeException(__('A root entity is required.', 'tenantwall'));
        }

        if ((int)$payload['is_active'] !== 1) {
            return;
        }

        $candidateScope = self::buildEffectiveEntityIds(
            (int)$payload['entities_id_root'],
            $extraIds,
            (int)$payload['include_children'] === 1
        );

        foreach (self::getAllActive() as $existing) {
            if ((int)$existing['id'] === $currentId) {
                continue;
            }

            $existingScope = self::getEffectiveEntityIds($existing);
            $overlap       = array_values(array_intersect($candidateScope, $existingScope));

            if ($overlap !== []) {
                throw new \RuntimeException(sprintf(
                    __('Tenant scope overlaps with existing tenant "%s" on entity IDs: %s', 'tenantwall'),
                    (string)$existing['name'],
                    implode(', ', array_slice($overlap, 0, 10))
                ));
            }
        }
    }

    private static function buildEffectiveEntityIds(int $rootId, array $extraIds, bool $includeChildren): array
    {
        $ids = $rootId > 0 ? [$rootId] : [];
        $ids = array_merge($ids, array_values(array_unique(array_map('intval', $extraIds))));

        if ($includeChildren && $rootId > 0) {
            $ids = array_merge($ids, self::getEntityDescendants($rootId));
        }

        return array_values(array_unique(array_filter(array_map('intval', $ids))));
    }

    private static function getEntityDescendants(int $rootId): array
    {
        global $DB;

        if ($rootId <= 0) {
            return [];
        }

        $descendants = [];
        $queue       = [$rootId];
        $seen        = [];

        while ($queue !== []) {
            $current = array_shift($queue);
            if (isset($seen[$current])) {
                continue;
            }
            $seen[$current] = true;

            foreach ($DB->request([
                'SELECT' => ['id'],
                'FROM'   => 'glpi_entities',
                'WHERE'  => ['entities_id' => $current],
            ]) as $row) {
                $childId = (int)$row['id'];
                if (!isset($seen[$childId])) {
                    $descendants[] = $childId;
                    $queue[] = $childId;
                }
            }
        }

        return $descendants;
    }

    private static function yesNoField(string $name, int $value, bool $canEdit): void
    {
        if ($canEdit) {
            Dropdown::showYesNo($name, $value);
            return;
        }

        $cls = $value ? 'bg-success' : 'bg-secondary';
        echo '<span class="badge ' . $cls . '">' . ($value ? __('Yes') : __('No')) . '</span>';
    }

    private static function buildSelect(
        string $name,
        int $current,
        array $options,
        bool $multiple = false,
        array $selected = [],
        bool $disabled = false
    ): string {
        $attrs = $multiple ? ' multiple size="10"' : '';
        if ($disabled) {
            $attrs .= ' disabled';
        }
        $html  = '<select class="form-select" name="' . htmlspecialchars($name, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '"' . $attrs . '>';

        if (!$multiple) {
            $html .= '<option value="0">' . __('None') . '</option>';
        }

        $selectedInts = array_map('intval', $selected);
        foreach ($options as $id => $label) {
            $isSelected = $multiple
                ? in_array((int)$id, $selectedInts, true)
                : ((int)$id === $current);

            $html .= '<option value="' . (int)$id . '"' . ($isSelected ? ' selected' : '') . '>'
                . htmlspecialchars($label, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '</option>';
        }

        return $html . '</select>';
    }
}
